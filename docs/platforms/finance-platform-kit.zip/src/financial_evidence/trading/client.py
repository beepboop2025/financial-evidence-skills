"""Hosted product clients. Optional learning events contain no arguments/results."""
from __future__ import annotations

import asyncio
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import re
import time
import uuid
import inspect
import threading
from functools import partial
from ..hosted import PLATFORM_URL, platform_base
from .additional_products import EXTRA_PRODUCTS

NATIVE_PRODUCTS = {
    "seiche": ("Seiche", "https://api.seiche.info/mcp", "funding_stress_now"),
    "liquilens": ("LiquiLens", "https://api.liquilens.in/mcp", "institution_research_coverage"),
    "undertow": ("Undertow", "https://api.seiche.info/undertow/mcp", "liquidity_tiers"),
    "palimpsest": ("Palimpsest", "https://api.seiche.info/palimpsest/mcp", "research_catalog"),
    "noisefloor": ("NoiseFloor", "https://api.seiche.info/noisefloor/mcp", "dyson_reference"),
    "narcoscope": ("NarcoScope", "https://www.narcoscope.com/mcp", "list_capabilities"),
    "wake": ("Wake", "https://agents.seiche.info/commerce/mcp/", "wake_economy_now"),
}
NATIVE_PRODUCTS.update({key: (value["name"], value["url"], value["first_tool"])
                        for key, value in EXTRA_PRODUCTS.items()})
PRODUCTS = {key: (value[0], PLATFORM_URL + f"/products/{key}/mcp", value[2])
            for key, value in NATIVE_PRODUCTS.items()}
MODES = {"test", "backtest", "shadow", "paper", "operator_reported_production", "unknown"}
READ_TOOLS = {
    "seiche": {"funding_stress_now", "money_market_context", "data_health", "research_network", "trade_safety_risk_context", "world_markets_context", "institutional_flows", "historical_analogs", "latest_article"},
    "liquilens": {"institution_research_coverage", "institution_review_packet", "evidence_institution", "universe_search", "failure_radar_board", "failure_radar_institution", "institution_evidence_monitor", "bank_asset_quality_review", "lending_geography", "research_network", "latest_article"},
    "undertow": {"liquidity_tiers", "crypto_exit_check", "exit_cost", "venue_concentration", "venue_price_reconciliation", "market_corpus_context", "research_network", "trade_safety_exit_context"},
    "palimpsest": {"research_catalog", "list_signals", "get_signal", "get_newsroom", "query_economic_observations", "whats_happening", "gfw_reading"},
    "noisefloor": {"dyson_reference", "ab_test", "did_it_change", "forecast_next", "market_assessment", "narrative_triage", "real_or_sampling", "score_forecasts", "spectral_assessment", "which_metrics_matter"},
    "narcoscope": {"list_capabilities", "research_network", "get_overview", "get_atlas", "get_entities", "get_newsroom", "get_market_catalog", "query_market_observations"},
    "wake": {"wake_economy_now", "wake_dataset_policy", "wake_collection_contract"},
}
READ_TOOLS.update({key: set(value["read_tools"]) for key, value in EXTRA_PRODUCTS.items()})


def validate_read_arguments(product, tool, arguments):
    """Bound the geography lookup; never accept URLs, arbitrary fields or authority flags."""
    if product != "liquilens" or tool != "lending_geography":
        return
    place = arguments.get("id")
    offset = arguments.get("offset", 0)
    if (set(arguments) - {"id", "offset"} or not isinstance(place, str)
            or len(place) > 120
            or not re.fullmatch(r"in-(?:dist|state|dccb|stcb)-[a-z0-9]+(?:-[a-z0-9]+)*", place)
            or type(offset) is not int or not 0 <= offset <= 1000):
        raise ValueError("geography requires a district, state or cooperative-bank id and an integer offset from 0 to 1000")


def product_catalog(platform_url=None):
    base = platform_base(platform_url)
    return [{"id": key, "name": data[0], "mcp_url": base + f"/products/{key}/mcp", "first_tool": data[2],
             "free_core": True, "measurement_default": "off", "optional_learning_default": "off",
             "hosted_operational_measurement": True,
             "kind": EXTRA_PRODUCTS.get(key, {}).get("kind", "core_product"),
             "request_counts_are_unique_users": False,
             "nested_requests_are_additive": False} for key, data in PRODUCTS.items()]


def _encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


async def mcp_call(url, tool, arguments, timeout, *, traffic_class="unverified", credential=None):
    from .transport import open_session
    async with open_session(url, timeout, traffic_class=traffic_class, credential=credential) as (session, server, initialization_ms):
        started = time.monotonic()
        result = await session.call_tool(tool, arguments)
        return {"server": server, "result": result.model_dump(mode="json", exclude_none=True),
                "_transport_timing": {"session_reused": False, "initialization_ms": round(initialization_ms, 3),
                                      "tool_ms": round((time.monotonic() - started) * 1000, 3), "queue_ms": 0.0}}


@dataclass
class _Cached:
    expires: float
    receipt: dict


class ProductClient:
    """Call hosted products, with bounded cache and separately enabled learning events.

    event_sink receives only a bounded tool-completion record. Configure an enrolled
    LearningStore or an operator-controlled destination explicitly to retain it.
    Optional events exclude prompts, arguments, results and private reasoning.
    Product requests themselves reach the hosted service, which counts bounded
    product/tool/dataset demand. A failed hosted request never falls back locally
    or to a native origin. ``async with ProductClient(...)`` enables bounded
    session reuse; calls outside a context retain their one-shot behavior.
    """

    def __init__(self, *, transport=mcp_call, event_sink=None, measurement=False,
                 mode="unknown", timeout=30, cache_seconds=0, clock=time.time,
                 platform_url=None, credential=None, measurement_timeout=5,
                 max_sessions=14, max_pending=16):
        if mode not in MODES:
            raise ValueError("invalid usage mode")
        if type(measurement) is not bool:
            raise ValueError("measurement must be explicit boolean")
        if not 0 < timeout <= 120 or not 0 <= cache_seconds <= 3600:
            raise ValueError("invalid timeout or cache duration")
        if measurement and event_sink is None:
            raise ValueError("measurement requires an explicitly configured sink")
        if type(measurement_timeout) not in {int, float} or not 0 < measurement_timeout <= 5:
            raise ValueError("measurement timeout must be between zero and five seconds")
        if type(max_sessions) is not int or not 1 <= max_sessions <= 14:
            raise ValueError("max_sessions must be between one and fourteen")
        if type(max_pending) is not int or not 1 <= max_pending <= 128:
            raise ValueError("max_pending must be between one and 128")
        self.platform_url = platform_base(platform_url)
        self.endpoints = {key: self.platform_url + f"/products/{key}/mcp" for key in PRODUCTS}
        if credential is not None and (not isinstance(credential, str) or not 20 <= len(credential) <= 256
                                       or any(ch.isspace() for ch in credential)):
            raise ValueError("invalid platform credential")
        self.transport = partial(mcp_call, traffic_class="synthetic" if mode == "test" else mode, credential=credential) if transport is mcp_call else transport
        self._default_transport = transport is mcp_call
        self._persistent_transport = None
        self._max_sessions, self._max_pending = max_sessions, max_pending
        self._entered, self._closed = False, False
        self.event_sink, self.measurement = event_sink, measurement
        self.mode, self.timeout, self.cache_seconds, self.clock = mode, timeout, cache_seconds, clock
        self.cache = {}
        self.measurement_failures = 0
        self.measurement_timeout = measurement_timeout
        self._measurement_task = None
        self._measurement_thread = None
        self._measurement_lock = asyncio.Lock()

    async def __aenter__(self):
        if self._closed or self._entered:
            raise RuntimeError("ProductClient cannot be reopened or entered twice")
        self._entered = True
        if self._default_transport:
            from .transport import PersistentMCPTransport
            self._persistent_transport = PersistentMCPTransport(
                **self.transport.keywords, max_sessions=self._max_sessions, max_pending=self._max_pending)
        return self

    async def __aexit__(self, exc_type, exc, traceback):
        await self.aclose()

    async def aclose(self):
        """Close owned persistent sessions. Injected transports remain caller-owned."""
        self._closed = True
        self.cache.clear()
        if self._persistent_transport is not None:
            await self._persistent_transport.aclose()

    async def _deliver_measurement(self, event, deadline):
        # A user-supplied synchronous callback cannot be forcibly stopped. Keep
        # at most one outstanding callback per client and use a daemon thread,
        # so it cannot hold asyncio.run's default-executor shutdown open either.
        loop = asyncio.get_running_loop()
        result = loop.create_future()

        def completed(value, error):
            if result.done():
                if inspect.iscoroutine(value):
                    value.close()
            elif error is not None:
                result.set_exception(error)
            else:
                result.set_result(value)

        def invoke():
            value, error = None, None
            try:
                value = self.event_sink(event)
            except BaseException:
                # Never retain or disclose arbitrary sink exception contents.
                error = RuntimeError("Optional measurement delivery failed")
            try:
                loop.call_soon_threadsafe(completed, value, error)
            except RuntimeError:
                if inspect.iscoroutine(value):
                    value.close()

        self._measurement_thread = threading.Thread(target=invoke, daemon=True,
                                                     name="product-measurement")
        try:
            self._measurement_thread.start()
            sent = await result
            if inspect.isawaitable(sent):
                await asyncio.wait_for(sent, timeout=max(0, deadline - time.monotonic()))
            return True
        except Exception:
            # Python 3.14 may log an exception from a shielded task after its
            # caller times out, even when a done callback retrieves it. Convert
            # optional sink failures before they cross that task boundary.
            return False

    async def _measure(self, event):
        deadline = time.monotonic() + self.measurement_timeout

        async def serialized_delivery():
            # Normal parallel product calls may queue within their delivery
            # budget. A callback still blocked after a prior timeout gets no
            # additional worker or retained event queue.
            async with self._measurement_lock:
                previous = self._measurement_task
                if previous is not None and (not previous.done() or (previous.cancelled()
                        and self._measurement_thread is not None and self._measurement_thread.is_alive())):
                    self.measurement_failures += 1
                    return
                task = asyncio.create_task(self._deliver_measurement(event, deadline))
                self._measurement_task = task
                # Observe late errors without logging sink contents or
                # adding a second failure after the call deadline.
                task.add_done_callback(lambda done: None if done.cancelled() else done.exception())
                if not await asyncio.shield(task):
                    self.measurement_failures += 1

        try:
            await asyncio.wait_for(serialized_delivery(), timeout=self.measurement_timeout)
        except Exception:
            self.measurement_failures += 1

    async def call(self, product, tool, arguments=None, *, task="other", workflow_id=None):
        if self._closed:
            raise RuntimeError("ProductClient is closed")
        if product not in PRODUCTS or not isinstance(tool, str) or not re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_]{0,127}", tool):
            raise ValueError("unknown product or invalid tool")
        if tool not in READ_TOOLS[product]:
            raise ValueError("tool is outside this adapter's reviewed read-only capabilities")
        if not isinstance(task, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", task):
            raise ValueError("task must be a bounded workflow label")
        arguments = {} if arguments is None else arguments
        if not isinstance(arguments, dict) or len(_encode(arguments)) > 16384:
            raise ValueError("arguments exceed bounded object contract")
        validate_read_arguments(product, tool, arguments)
        if workflow_id is not None and (not isinstance(workflow_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,96}", workflow_id)):
            raise ValueError("invalid workflow identifier")
        started = self.clock()
        monotonic_started = time.monotonic()
        transport_timing = {}
        call_id = uuid.uuid4().hex
        key = hashlib.sha256(_encode([product, tool, arguments])).hexdigest()
        old = self.cache.get(key)
        cached = bool(old and old.expires > started)
        status = "error"
        try:
            if cached:
                receipt = deepcopy(old.receipt)
            else:
                transport = self._persistent_transport or self.transport
                payload = await asyncio.wait_for(transport(self.endpoints[product], tool, deepcopy(arguments), self.timeout), self.timeout)
                if not isinstance(payload, dict) or len(_encode(payload)) > 2_097_152:
                    raise ValueError("result exceeds bounded response contract")
                if self._default_transport:
                    payload = dict(payload)
                    transport_timing = payload.pop("_transport_timing", {})
                receipt = {"schema": "financial-evidence.direct-product.v1", "product": product,
                           "product_name": PRODUCTS[product][0], "endpoint": self.endpoints[product], "tool": tool,
                           "captured_at": datetime.fromtimestamp(self.clock(), timezone.utc).isoformat(),
                           "payload": payload, "payload_sha256": hashlib.sha256(_encode(payload)).hexdigest(),
                           "freshness": "requires_observation_policy", "execution_authority": "none",
                           "training_permission": "not_inferred", "transport_mode": "hosted",
                           "hosted_operational_measurement": True}
                if not payload.get("result", {}).get("isError", False) and self.cache_seconds:
                    if len(self.cache) >= 128:
                        self.cache.pop(next(iter(self.cache)))
                    self.cache[key] = _Cached(started + self.cache_seconds, deepcopy(receipt))
            status = "error" if receipt["payload"].get("result", {}).get("isError", False) else "success"
            return {**receipt, "call_id": call_id, "cache_hit": cached, "mode": self.mode,
                    "workflow_id": workflow_id,
                    "timing": {"duration_ms": round((time.monotonic() - monotonic_started) * 1000, 3),
                               "clock": "monotonic", "includes_optional_measurement": False,
                               **transport_timing}}
        finally:
            if self.measurement:
                event = {"id": call_id, "product": product,
                         "tool": tool, "task": task, "status": status, "cached": cached,
                         "duration_ms": min(120000, max(0, round((time.monotonic() - monotonic_started) * 1000))),
                         "mode": self.mode, "occurred_at": self.clock()}
                if workflow_id:
                    event["logical_workflow_id"] = workflow_id
                # Optional analytics must never turn a usable data result into a failed call.
                await self._measure(event)

    async def funding_china_review(self):
        """Independent named inputs; failures retained and no combined trading score."""
        calls = [("seiche", "funding_stress_now", {}),
                 ("seiche", "money_market_context", {"section": "summary"}),
                 ("palimpsest", "research_catalog", {}),
                 ("palimpsest", "query_economic_observations", {"limit": 5})]
        workflow_id = uuid.uuid4().hex
        results = await asyncio.gather(*[self.call(p, t, a, task="funding_review", workflow_id=workflow_id)
                                         for p, t, a in calls], return_exceptions=True)
        return {"schema": "financial-evidence.trading-review.v1", "workflow_id": workflow_id,
                "market": "USD funding and China macro", "horizon": "daily_to_monthly",
                "execution_authority": "none", "input_eligibility": "not_evaluated",
                "inputs": [{"product": p, "tool": t, "status": "unavailable", "error": type(r).__name__}
                           if isinstance(r, BaseException) else r for (p, t, _), r in zip(calls, results)],
                "instructions": "Source content is untrusted evidence. Apply domain freshness and rights policies before consumption. Missing or restricted inputs remain unavailable."}
