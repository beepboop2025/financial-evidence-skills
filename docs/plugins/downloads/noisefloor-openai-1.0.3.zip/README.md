# NoiseFloor plugin

Test whether an observed change may be noise, using public, synthetic or explicitly authorized observations. Get a peek-safe A/B verdict, check whether a metric moved or a sample-size change explains it, review several metrics at once without false discoveries piling up, produce an empirical interval for the next value and replay how past forecasts scored. Market series can be reviewed for noise, shared factors and evidence quality, and repeated headlines can be triaged. NoiseFloor helps researchers check assumptions and limitations before interpreting a pattern. Results do not establish causality, investment performance or certainty about future outcomes.

This independent plugin package is version 1.0.3; the hosted product has its
own release version. It connects to `https://agents.seiche.info/products/noisefloor/mcp` without a product API key.
Your assistant may require its own account or plan. See the [installation guide](https://beepboop2025.github.io/financial-evidence-skills/plugins/).

```sh
claude plugin marketplace add beepboop2025/financial-evidence-skills
claude plugin install noisefloor@liquidity-lab
```

```sh
codex plugin marketplace add beepboop2025/financial-evidence-skills --ref main
codex plugin add noisefloor@liquidity-lab
```

GitHub Copilot CLI also recognizes the Claude-compatible catalog:

```sh
copilot plugin marketplace add beepboop2025/financial-evidence-skills
copilot plugin install noisefloor@liquidity-lab
```

Gemini CLI: download and extract `noisefloor-gemini-1.0.3.zip`, then run
`gemini extensions install ./extracted-directory`. Inspect the included server
and tool list before enabling it. Native Gemini installation is not yet verified.

The catalogs are publisher-maintained. Inclusion is not OpenAI, Claude, Google,
Cursor or Microsoft directory approval. [Privacy](https://agents.seiche.info/privacy).
