# Financial Evidence platform kit

Start at docs/platforms/agent-clients.md or choose a platform in routes.json.
Forward quant examples: integrations/finance-research/README.md.
Recurring agent reviews and optional outcome delivery: docs/start/agent-workflows.md.
Desktop candidate: integrations/finance-desktop/README.md.
Institutional packets: docs/distribution/provider-packets-20261011/README.md.
Native automation candidates and receipts: docs/platforms/native-packages.md.
Existing Flowise 3.1.4 users: docs/platforms/flowise/README.md (upstream is EOL).
Python/Colab research notebook, Google Sheets and Power Query: docs/tools/.
Node-RED manual research flow: docs/automations/node-red/.
The shared Python package source and pyproject.toml are included, so the setup
commands in the forward-research README work from this extracted directory.

This is an evaluation kit, not a claim of marketplace acceptance or adoption.
Our software licence is in LICENSE. Flowise-derived template metadata retains
the upstream licence and attribution in docs/platforms/flowise/.
Upstream data retains its source-specific terms.
Retain observation and availability clocks; never backfill current captures into
historical decisions. No broker credentials or order execution is included.
