# Financial Evidence platform kit

Start at docs/platforms/agent-clients.md or choose a platform in routes.json.
Forward quant examples: integrations/finance-research/README.md.
Desktop candidate: integrations/finance-desktop/README.md.
Institutional packets: docs/distribution/provider-packets-20261011/README.md.
Native automation candidates and receipts: docs/platforms/native-packages.md.
Python research client and Power Query: docs/tools/.
The shared Python package source and pyproject.toml are included, so the setup
commands in the forward-research README work from this extracted directory.

This is an evaluation kit, not a claim of marketplace acceptance or adoption.
Software licence is in LICENSE. Upstream data retains its source-specific terms.
Retain observation and availability clocks; never backfill current captures into
historical decisions. No broker credentials or order execution is included.
